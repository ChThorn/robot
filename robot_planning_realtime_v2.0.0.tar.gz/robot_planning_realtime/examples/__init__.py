"""
Example scripts for robot planning library.
"""

