"""
Test suite for robot planning library.
"""

