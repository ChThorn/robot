"""
Example scripts for robot kinematics package.
"""

